import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MainClass {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.tendable.com/");
		
		//Challenge 1 ==>> Solution 
		
		WebElement homeElement = driver.findElement(By.xpath("//a[@aria-label='home']"));
		
		if (homeElement.isEnabled()) {
            System.out.println("The Home is accessible on the Tendable website.");
        } else {
            System.out.println("The Home is NOT accessible.");
        }	
		
		WebElement ourStoryElement = driver.findElement(By.xpath("//a[text()='About']"));
		
		if (ourStoryElement.isEnabled()) {
            System.out.println("The Our Story is accessible on the Tendable website.");
        } else {
            System.out.println("The Our Story is NOT accessible.");
        }	
		
		WebElement ourSolutionElement = driver.findElement(By.xpath("//a[text()='Products']"));
		
		if (ourSolutionElement.isEnabled()) {
            System.out.println("The Our Solution is accessible on the Tendable website.");
        } else {
            System.out.println("The Our Solution is NOT accessible.");
        }	
		
		
		
		//Challenge 2 ==>> Solution 
		
		 List<WebElement> menuItems = driver.findElements(By.xpath("//a[@class='navbar7_link w-nav-link']"));
		 
		 for (int i = 0; i < menuItems.size(); i++) {
             menuItems = driver.findElements(By.xpath("//a[@class='navbar7_link w-nav-link']"));
             WebElement menuItem = menuItems.get(i);
             
             String menuName = menuItem.getText();
             System.out.println("Navigating to: " + menuName);
             // Click the menu item
             menuItem.click();

             // Verify if the "Request a Demo" button is present and active
             WebElement demoButton = driver.findElement(By.xpath("//a[@class='button is-small w-button']"));
             if (demoButton.isDisplayed() && demoButton.isEnabled()) {
                 System.out.println("'Request a Demo' button is present and active on: " + menuName);
             } else {
                 System.out.println("'Request a Demo' button is NOT active on: " + menuName);
             }

             // Navigate back to the homepage
             driver.navigate().back();
             
         }
		
		//Challenge 3 ==>> Solution
		 
		 driver.findElement(By.xpath("//a[text()='Contact']")).click();
		
		 WebElement dropdown = driver.findElement(By.xpath("(//select[@id='message_type'])[1]"));
		 dropdown.click();
		 driver.findElement(By.xpath("//option[text()='Marketing']")).click();
		 
		 driver.findElement(By.xpath("(//input[@id='email'])[1]")).sendKeys("abc@gmail.com");
		 driver.findElement(By.xpath("(//input[@id='firstname'])[1]")).sendKeys("Rohit");
		 driver.findElement(By.xpath("//input[@name='lastname']")).sendKeys("Gawande");
		 driver.findElement(By.xpath("(//input[@id='company'])[1]")).sendKeys("Cognizant");
		 driver.findElement(By.xpath("(//input[@name='384607520'])[1]")).click();
		 
		 driver.findElement(By.xpath("(//button[@type='submit'][normalize-space()='Submit'])[1]")).click();
		
		 boolean isErrorDisplayed = driver.findElements(By.xpath("//span[contains(text(), 'Message field is required')]")).isEmpty();
		 if (isErrorDisplayed) {
		     System.out.println("Test PASS: Error message is displayed when 'Message' is empty.");
		 } else {
		     System.out.println("Test FAIL: Error message NOT displayed.");
		 }
		
		driver.quit();
		
	}
	
}
